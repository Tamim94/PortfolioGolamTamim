package com.example.portfolio_tamim

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
