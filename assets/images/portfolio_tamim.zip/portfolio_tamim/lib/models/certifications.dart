
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

class Certifications {
  final String title, description,link;

  Certifications({required this.title, required this.description,required this.link});

}

List<Certifications> demo_certifications = [
  Certifications(
    title: "Cisco\nIoT Fundamental",
    description:
    "" ,
      link:"",
  ),
  Certifications(
    title: "Pix 2022",
    description:
    "",
    link:"",
  ),
  Certifications(
    title: "React udemy 2022",
    description:
    "",
      link:"https://bb8d0c39-4de1-4690-9c13-013194a8580b.filesusr.com/ugd/0bdab9_9a50f53eee164a24bd181123627a08ee.pdf",
  ),
  Certifications(
    title: "Futur",
    description:
    ".",
     link: ""
  ),
];









